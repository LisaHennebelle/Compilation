cd Tests/Syntaxe/OK
pwd
ls
sudo rm *
echo "fini dans Tests/Syntaxe/ok"
ls

cd ../KO
ls
sudo rm *
echo "fini dans Tests/Syntaxe/KO"
ls

cd ../../Verif/OK
pwd
ls
sudo rm *
echo "fini dans Tests/Verif/ok"
ls


cd ../KO
pwd
ls
sudo rm *
echo "fini dans Tests/Verif/KO"
ls

cd ../../Gencode/OK
pwd
ls
sudo rm *
echo "fini dans Tests/Gencode/ok"
ls

cd ../KO
pwd
ls
sudo rm *
echo "fini dans Tests/Gencode/KO"
ls

cd ../../..
